from flask import Flask, request, jsonify, render_template_string
from math import radians, sin, cos, sqrt, atan2
from time import time

app = Flask(__name__)

# In-memory live positions for the MVP.
# Later we can replace this with Firebase/Redis/PostgreSQL for production.
BUSES = {
    "BUS-01": {"lat": 11.0168, "lng": 76.9558, "speed": 0, "updated": None},
    "BUS-02": {"lat": 11.0200, "lng": 76.9620, "speed": 0, "updated": None},
    "BUS-03": {"lat": 11.0250, "lng": 76.9700, "speed": 0, "updated": None},
}

HTML = r"""
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>BusLive — 3 Bus Tracking</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
*{box-sizing:border-box} body{margin:0;font-family:Arial,sans-serif;background:#f4f7fb;color:#172033}
header{background:#173b7a;color:white;padding:16px 18px}
header h1{margin:0;font-size:22px} header p{margin:5px 0 0;opacity:.85;font-size:13px}
.wrap{padding:14px;max-width:1200px;margin:auto}.grid{display:grid;grid-template-columns:1.6fr 1fr;gap:14px}
.card{background:white;border-radius:16px;padding:14px;box-shadow:0 4px 18px #00000012}
#map{height:520px;border-radius:12px}.bus{border:1px solid #e4e8ef;border-radius:12px;padding:12px;margin:9px 0}
.row{display:flex;justify-content:space-between;gap:8px}.badge{font-size:12px;padding:5px 8px;border-radius:20px;background:#e9f8ee;color:#19733b}
.badge.warn{background:#fff3d8;color:#8a5b00}.badge.danger{background:#ffe5e5;color:#a12626}
.stat{font-size:13px;color:#596579;margin-top:7px}.big{font-size:19px;font-weight:700}
button{border:0;background:#173b7a;color:white;border-radius:9px;padding:10px 12px;font-weight:700}
input,select{padding:10px;border:1px solid #ccd4df;border-radius:9px;width:100%;margin:5px 0 10px}
#notice{font-size:13px;margin-top:8px;color:#596579}.section-title{margin:0 0 10px}
@media(max-width:800px){.grid{grid-template-columns:1fr}#map{height:420px}}
</style>
</head>
<body>
<header><h1>🚌 BusLive</h1><p>Real-time 3-bus tracking • distance • ETA • bunching analysis</p></header>

<div class="wrap">
<div class="grid">
  <div class="card"><h3 class="section-title">Live Map</h3><div id="map"></div></div>
  <div>
    <div class="card">
      <h3 class="section-title">Passenger View</h3>
      <div id="cards"></div>
    </div>
    <div class="card" style="margin-top:14px">
      <h3 class="section-title">Driver GPS</h3>
      <label>Bus</label>
      <select id="busSelect">
        <option>BUS-01</option><option>BUS-02</option><option>BUS-03</option>
      </select>
      <button onclick="startGPS()">Start live GPS</button>
      <div id="notice">Choose a bus on this device, then allow location permission.</div>
    </div>
  </div>
</div>
</div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const map = L.map('map').setView([11.020,76.962],14);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
 {maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);
const markers = {};
const colors = {};
const palette = ['#173b7a','#e35b2d','#198754'];

function hav(a,b){
 const R=6371, p1=a.lat*Math.PI/180,p2=b.lat*Math.PI/180;
 const dp=(b.lat-a.lat)*Math.PI/180, dl=(b.lng-a.lng)*Math.PI/180;
 const x=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;
 return 2*R*Math.atan2(Math.sqrt(x),Math.sqrt(1-x));
}
function mins(km, speed){ return speed>2 ? Math.max(1,Math.round(km/speed*60)) : null; }

async function refresh(){
 const r=await fetch('/api/buses'); const buses=await r.json();
 const ids=Object.keys(buses);
 ids.forEach((id,i)=>{
   const b=buses[id]; colors[id]=palette[i];
   if(!markers[id]){
     markers[id]=L.circleMarker([b.lat,b.lng],{radius:9,color:palette[i],fillColor:palette[i],fillOpacity:.95})
       .addTo(map).bindTooltip(id,{permanent:true,direction:'top'});
   } else markers[id].setLatLng([b.lat,b.lng]);
 });
 let html='';
 ids.forEach((id,i)=>{
   const b=buses[id];
   let nearest=999, nearestBus='';
   ids.forEach(j=>{if(ids[j]!==id){const d=hav(b,buses[ids[j]]);if(d<nearest){nearest=d;nearestBus=ids[j]}}});
   const eta=mins(nearest,b.speed);
   const age=b.updated ? Math.round((Date.now()/1000-b.updated)) : null;
   const offline=age===null || age>30;
   let status=offline?'Offline':'Moving';
   let cls=offline?'danger':'';
   if(b.speed<3 && !offline){status='Stopped';cls='warn'}
   const bunch = nearest < 0.5;
   html += `<div class="bus">
      <div class="row"><strong>${id}</strong><span class="badge ${bunch?'warn':''}">${bunch?'⚠️ Bunching':'● '+status}</span></div>
      <div class="stat">Speed: <b>${b.speed.toFixed(1)} km/h</b> &nbsp; • &nbsp; Updated: ${age===null?'—':age+'s ago'}</div>
      <div class="stat">Nearest bus: <b>${nearestBus||'—'}</b> &nbsp; • &nbsp; Gap: <b>${nearest<999?nearest.toFixed(2)+' km':'—'}</b></div>
      <div class="stat">Estimated gap time: <b>${eta?eta+' min':'—'}</b></div>
      ${bunch?'<div class="stat" style="color:#a05a00"><b>Traffic bunching detected</b> — buses are within 500 m.</div>':''}
   </div>`;
 });
 document.getElementById('cards').innerHTML=html;
}
let watchId=null;
function startGPS(){
 if(!navigator.geolocation){alert('GPS is not supported on this device/browser.');return}
 const bus=document.getElementById('busSelect').value;
 if(watchId!==null) navigator.geolocation.clearWatch(watchId);
 document.getElementById('notice').textContent='GPS started for '+bus+'. Keep this page open and allow location access.';
 watchId=navigator.geolocation.watchPosition(async pos=>{
   const body={bus,lat:pos.coords.latitude,lng:pos.coords.longitude,speed:(pos.coords.speed||0)*3.6};
   await fetch('/api/location',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
   refresh();
 },err=>{document.getElementById('notice').textContent='GPS error: '+err.message}, {enableHighAccuracy:true,maximumAge:3000,timeout:10000});
}
refresh(); setInterval(refresh,3000);
</script>
</body>
</html>
"""

@app.get("/")
def home():
    return render_template_string(HTML)

@app.get("/driver")
def driver():
    return render_template_string(HTML)

@app.get("/api/buses")
def api_buses():
    return jsonify(BUSES)

@app.post("/api/location")
def api_location():
    data = request.get_json(silent=True) or {}
    bus = data.get("bus")
    if bus not in BUSES:
        return jsonify({"error":"Unknown bus"}), 400
    try:
        lat=float(data["lat"]); lng=float(data["lng"])
        speed=max(0.0,float(data.get("speed",0)))
    except (KeyError, TypeError, ValueError):
        return jsonify({"error":"Invalid GPS data"}), 400
    BUSES[bus].update({"lat":lat,"lng":lng,"speed":speed,"updated":time()})
    return jsonify({"ok":True,"bus":bus})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)
